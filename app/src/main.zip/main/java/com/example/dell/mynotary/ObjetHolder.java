package com.example.dell.mynotary;

import java.util.ArrayList;

/**
 * Created by DELL on 2/17/2017.
 */

public class ObjetHolder {
    public static ArrayList<CaseDetailsModel> caseDetailsList;
    public static ArrayList<SchedulelistModel> schedulelistModels;

}
