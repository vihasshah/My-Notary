package com.example.dell.mynotary;

/**
 * Created by DELL on 2/21/2017.
 */

public class SchedulelistModel {
   private String day;
    private String time;
    private String subject;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
